import React, { Component } from 'react';

import Table from '../table/table';
import CurrencyRate from '../currency-rate/currency-rate';
import ItemAddForm from '../item-add-form/item-add-form';
import PageRight from '../page-right/page-right';
import Sum from '../sum/sum';
import './app.css';

export default class App extends Component {

  maxId = 999;
  state = {
    items: [],
    currencyRate:1
  };
  onItemAdded = (name, eur) => {
    this.setState((state) => {
      const item = this.createItem(name, eur);
      return { items: [...state.items, item] };
    })
  };
  currencyRate = (currencyRate) => {
    this.setState(() => {
      return { currencyRate: currencyRate };
    })
  };
  createItem(name, eur) {
    return {
      id: ++this.maxId,
      name,
      eur,
      pln:String(eur*this.state.currencyRate)
    };
  };  

  onDelete = (id) => {
    this.setState((state) => {
      const idx = state.items.findIndex((item) => item.id === id);
      const items = [
        ...state.items.slice(0, idx),
        ...state.items.slice(idx + 1)
      ];
      return { items };
    });
  };

  render() {
    const { items } = this.state;
    console.log('items: ', items);
    return (
      <div className="marg">
        {/* <AppHeader /> */}
        <CurrencyRate currencyRate={this.currencyRate}/>
        <Table onDelete={this.onDelete} items={items} />
        <ItemAddForm onItemAdded={this.onItemAdded} />
        <PageRight items={items} />
        <Sum items={items} />
        {/* <AppFooter /> */}
      </div>
    );
  };
}
